package com.scb.api.controller;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.scb.api.bologic.Servicelogic;
import com.scb.api.configuration.Codeconfig;

@RestController
@RequestMapping("/teleapps")
public class APiController {    
	
	@Autowired
	private Environment env;		
	
	@Autowired
	private Codeconfig cd;
	
	@Autowired
	private Servicelogic srvlogic;	
	
	@PostMapping(path="sendSms/{number}",produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String postSmsByNumber(@Valid @RequestBody 
    		@PathVariable(value = "number") String number, @RequestParam("code") String code) { 		 
			if(!cd.getallcodes().containsKey(code)) {
				  return "{\"Error\":\"Please pass the correct code in the URL\"}";				
			  }		
			 if(!isNumeric(number)) {    	    	
	 	    	return "{\"Error\":\"Please provide a valid mobile number\"}";				    	    	
	 	    }    			
 	    	String finalurl = env.getProperty("Smsapi.Url")+number;
            String output=Apipost.posturl(finalurl);    	     
            String mergedoutput = null;		
			mergedoutput = srvlogic.mergeresponse(output,cd.getallcodes(),code);			
         	return mergedoutput;  
    }  	
	
	@ExceptionHandler(MissingServletRequestParameterException.class)
	@PostMapping(produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String  handleMissingParams(MissingServletRequestParameterException ex) {	    	
	    return "{\"Error\":\"Please pass the code parameter in the URL\"}";		    
	}	
    
    @PostMapping(path="sendSms/",produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String Emptyvalidation() {
    	return "{\"Error\":\"No mobile Number is Passed in the url\"}";		      
    }     
           
    public static boolean isNumeric(final String str) {
        if (str == null || str.length() == 0) {
            return false;
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }   
}