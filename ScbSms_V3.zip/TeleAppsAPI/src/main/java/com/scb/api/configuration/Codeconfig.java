package com.scb.api.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:code.properties"})
public class Codeconfig
{			
	final static Logger logger = LoggerFactory.getLogger(Codeconfig.class);
	public Properties getallcodes() {
		Properties props = new Properties();		
		try (InputStream is = getClass().getResourceAsStream("/code.properties")) {		
			props.load(is); 				
		} catch (IOException e) {
			 logger.info(e.getMessage());		
		}
		return props;		
	}
}