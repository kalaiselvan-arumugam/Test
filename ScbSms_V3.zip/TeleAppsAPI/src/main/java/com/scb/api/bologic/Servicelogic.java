package com.scb.api.bologic;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class Servicelogic {
	
	final static Logger logger = LoggerFactory.getLogger(Servicelogic.class);
	
	public String mergeresponse(String output, Properties properties, String code) {	
		String description=(String) properties.get(code);
		String status = null;
		String[] splittedvalues = output.split(",");
		String errorcode = null;
			try {	
						errorcode = splittedvalues[1].replace("\"", "").replace("}", "").replace("code:", "");	
				} catch (Exception e) {
					 logger.info(e.getMessage());		
				}
					if(output.contains("Failed")) {										
						return output;
					}else if(output.contains("200")) {				
						return "{\"status\":\"sent\",\"code\":\"200\",\""+code+"\":\""+description+"\"}" ;
					}else {		
						if(errorcode.equals("800")) {
							status = "insufficient balance";
						}if(errorcode.equals("801")) {
							status = "queue busy";
						}if(errorcode.equals("802")) {
							status = "server busy";
						}if(errorcode.equals("803")) {
							status = "number not exist";
						}if(errorcode.equals("804")) {
							status = "blocked by provider";
						}if(errorcode.equals("400")) {
							status = "Request is not Passed correctly";
						}if(errorcode.equals("404")) {
							status = "Response not Received from server";
						}
						return "{\"status\":\""+status+"\",\"code\":\""+errorcode+"\",\""+code+"\":\""+description+"\"}" ;				
					}				
	}	
}

