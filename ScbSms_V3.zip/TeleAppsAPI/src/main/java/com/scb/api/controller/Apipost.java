package com.scb.api.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Apipost {	
	final static Logger logger = LoggerFactory.getLogger(Apipost.class);	
	
	public static String posturl(String apiurl) {		
	  try {		      
				URL url = new URL(apiurl);			
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				//conn.setDoInput(true);
				conn.setDoOutput(true);				
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestMethod("POST");	
				OutputStream os = conn.getOutputStream();		
				os.flush();		
			
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));		
				StringBuffer sb=new StringBuffer();  			
				String output;		
				while ((output = br.readLine()) != null) {				
					sb.append(output);
				}								    
				logger.info("Response Received From server : "+sb);
				conn.disconnect();
				return sb.toString();			
		  } catch (MalformedURLException e) {
			  logger.info(e.getMessage());			
		  } catch (IOException e) {
			  logger.info(e.getMessage());			  
		 }		
		return "{\"Failed to get Response.....\":\"No Response Received From server\"}";			
	}	
}