package com.scb.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeleAppsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
